#!/usr/bin/perl
#
use strict ;

use App::Framework::Modules::Script ;

# VERSION
our $VERSION = '1.000' ;


	# Create application and run it
	App::Framework::Modules::Script->new()->go() ;

#=================================================================================
# SUBROUTINES EXECUTED BY APP
#=================================================================================

#----------------------------------------------------------------------
# Main execution
#
sub run
{
	my ($app) = @_ ;
	
	# Get source/dest dirs
	my ($src_dir, $backup_dir) = @{$app->arglist()};
	
}


#=================================================================================
# LOCAL SUBROUTINES
#=================================================================================

#=================================================================================
# SETUP
#=================================================================================
__DATA__


[HISTORY]

28-May-08    SDP        New

[SUMMARY]

Back up rip convert control files

[NAMEARGS]

src_dir:id backup_dir:id

[DESCRIPTION]

B<$name> scans through a directory (and it's subdirectories) looking for rip control files. Stores
any files it finds in a replica of the directory structure, but located under the backup directory.

